//
//  AddNewFriendViewController.h
//  Roads
//
//  Created by if26 on 20/12/12.
//  Copyright (c) 2012 com.utt.if26. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddNewFriendViewController : UIViewController

@property (retain, nonatomic) IBOutlet UILabel *addFriendAsk;
- (IBAction)btnAddFriendClicked:(id)sender;

@end
