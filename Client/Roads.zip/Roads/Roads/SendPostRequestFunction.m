//
//  SendPostRequestFunction.m
//  Roads
//
//  Created by if26 on 18/12/12.
//  Copyright (c) 2012 com.utt.if26. All rights reserved.
//

#import "SendPostRequestFunction.h"

@implementation SendPostRequestFunction

+ (NSString *) postRequest:(NSMutableDictionary *)params withUrl:(NSString *)url{
    
    //Créer une requête de type POST à partir d'un URL
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:url]];
    [request setHTTPMethod:@"POST"];
    
    //Créer un NSString pour stocker les données à envoyer
    NSString* sPostData = @"";
    for (NSString* key in params) {
        NSString* value = [params objectForKey:key];
        sPostData = [sPostData stringByAppendingString:key];
        sPostData = [sPostData stringByAppendingString:@"="];
        sPostData = [sPostData stringByAppendingString:value];
        sPostData = [sPostData stringByAppendingString:@"&"];
    }
    
    //Intégrer ce NSString dans le body de la requête
    [request setHTTPBody:[sPostData dataUsingEncoding:NSUTF8StringEncoding]];
    
    //Anticiper l'erreur eventuelle et la réponse
    NSError *error = [[NSError alloc] init];
    NSHTTPURLResponse *responseCode = nil;
    
    //Envoyer la requête et obtenir la réponse
    NSData *oResponseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&responseCode error:&error];
    NSString *strData;
    if(oResponseData == nil) {
        if(error != nil) {
            strData = nil;
        }
    } else {
        //Récupérer le résultat et le retourner
        strData = [[NSString alloc]initWithData:oResponseData encoding:NSUTF8StringEncoding];
    }
    
    return strData;
}


@end
