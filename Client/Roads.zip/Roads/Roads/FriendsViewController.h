//
//  FriendsViewController.h
//  Roads
//
//  Created by if26 on 20/12/12.
//  Copyright (c) 2012 com.utt.if26. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FriendsViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, retain) NSMutableArray* friendsList;
- (IBAction)btnAddFriendClicked:(id)sender;
@property (retain, nonatomic) IBOutlet UITableView *friendsListView;

@end
