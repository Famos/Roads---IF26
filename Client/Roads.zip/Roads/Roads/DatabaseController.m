//
//  DatabaseController.m
//  Roads
//
//  Created by if26 on 10/01/13.
//  Copyright (c) 2013 com.utt.if26. All rights reserved.
//

#import "DatabaseController.h"
#import "User.h"


#import <Foundation/Foundation.h>
#import "NSData+AES.h"
#import "NSData+Base64.h"
#import "NSString+Base64.h"


@implementation DatabaseController

- (void)createOrOpenDB {
    NSArray *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docPath = [path objectAtIndex:0];
    
    dbPathString = [docPath stringByAppendingPathComponent:@"localDB.sql"];
    
    char *error;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if (![fileManager fileExistsAtPath:dbPathString]) {
        const char *dbPath = [dbPathString UTF8String];
        
        //Créer la base de données locale
        if (sqlite3_open(dbPath, &localDB)==SQLITE_OK) {
            const char *sql_stmt = "CREATE TABLE IF NOT EXISTS user (username TEXT)";
            sqlite3_exec(localDB, sql_stmt, NULL, NULL, &error);
            sqlite3_close(localDB);
        }
    }
}

//Ajouter l'identifiant de l'utilisateur en local pour ne pas se réauthntifier la prochaine fois
- (void)addUser {
    User* user = [User getInstance];
    
    //Crypter l'identifiant
    NSString* key = @"abcdefghijklmnopqrstuvwxyz123456";
    NSData* cipherData;
    NSString* plainText; //Le text à crypter, à savoir l'identifiant l'utilisateur
    NSString* base64Text;

    plainText  = [user login];
    cipherData = [[plainText dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKey:key];
    base64Text = [cipherData base64EncodedString];
    NSLog(@"l'identifiant crypté = %@", base64Text);
    
    //Enregistrer l'identifiant crypté dans la base de données locale
    char *error;
    if (sqlite3_open([dbPathString UTF8String], &localDB)==SQLITE_OK) {
        NSString *inserStmt = [NSString stringWithFormat:@"INSERT INTO user(username) values ('%s')",[base64Text UTF8String]]; 
        const char *insert_stmt = [inserStmt UTF8String];
        if (sqlite3_exec(localDB, insert_stmt, NULL, NULL, &error)==SQLITE_OK) {
            NSLog(@"User added");
        }
        sqlite3_close(localDB);
    }
}

//Récupérer l'identifiant de l'utilisateur chiffré dans la base de données locale afin de le faire logger automatiquement
- (void)getUser {
    User* user = [User getInstance];
    
    NSString* key = @"abcdefghijklmnopqrstuvwxyz123456";
    NSData* cipherData;
    NSString* name; //Le text à décrypter, à savoir l'identifiant l'utilisateur
    NSString* base64Text;
    
    //Entrer dans la base de données locale
    sqlite3_stmt *statement;
    if (sqlite3_open([dbPathString UTF8String], &localDB)==SQLITE_OK) {
        NSString *querySql = [NSString stringWithFormat:@"SELECT * FROM user"];
        const char* query_sql = [querySql UTF8String];
        
        if (sqlite3_prepare(localDB, query_sql, -1, &statement, NULL)==SQLITE_OK) {
            while (sqlite3_step(statement)==SQLITE_ROW) {
                base64Text = [[NSString alloc]initWithUTF8String:(const char *)sqlite3_column_text(statement, 0)];
                NSLog(@"l'identifiant récupéré doit être crypté : %@", base64Text);
                
                //cipherData = [base64Text base64DecodedData];
                //name =[[NSString alloc] initWithData:[cipherData AES256DecryptWithKey:key] encoding:NSUTF8StringEncoding];
                //NSLog(@"l'identifiant décrypté %@", name);
                [user setLogin:base64Text];
            }
        }
    }
}

//Effacer l'identifiant dans la base de données une fois que l'utilisateur appuie sur le bouton "Déconnexion"
- (void)deleteUser {
    User* user = [User getInstance];
    [user setLogin:nil];
    sqlite3_stmt *statement;
    if (sqlite3_open([dbPathString UTF8String], &localDB)==SQLITE_OK) {
        NSString *querySql = [NSString stringWithFormat:@"DELETE FROM user"];
        const char* query_sql = [querySql UTF8String];
        
        if (sqlite3_prepare(localDB, query_sql, -1, &statement, NULL)==SQLITE_OK) {
            while (sqlite3_step(statement)==SQLITE_ROW) {
                NSString *name = [[NSString alloc]initWithUTF8String:(const char *)sqlite3_column_text(statement, 0)];
                [user setLogin:name];
            }
        }
    }
}


@end
