//
//  ErrorNetworkViewController.h
//  Roads
//
//  Created by if26 on 19/12/12.
//  Copyright (c) 2012 com.utt.if26. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ErrorNetworkViewController : UIViewController

- (IBAction)backAuth:(id)sender;

@end
