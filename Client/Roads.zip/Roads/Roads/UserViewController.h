//
//  UserViewController.h
//  Roads
//
//  Created by if26 on 18/12/12.
//  Copyright (c) 2012 com.utt.if26. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <MapKit/MKAnnotation.h>
#import <CoreLocation/CoreLocation.h>
#import "MyAnnotation.h"

@interface UserViewController : UIViewController <MKMapViewDelegate, UISearchBarDelegate, CLLocationManagerDelegate> {
    IBOutlet MKMapView* myMapView;
    BOOL isUpdatingRoutes;
    
    CLLocationManager* locationManager;
}

//Liste d'amis de l'utilisateur
@property (nonatomic, retain) NSMutableArray* friendsList;
@property (nonatomic, retain) IBOutlet MKMapView* myMapView;
@property (retain, nonatomic) IBOutlet UISearchBar *searchFriend;
@property (nonatomic, retain) NSArray* routes;
@property (nonatomic, assign) int isItinerary;

- (IBAction)setMap:(id)sender;
- (IBAction)menuClicked:(id)sender;
- (void) showItinerary: (MyAnnotation*) f to: (MyAnnotation*) t;

@end
