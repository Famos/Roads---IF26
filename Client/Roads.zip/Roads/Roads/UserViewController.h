//
//  UserViewController.h
//  Roads
//
//  Created by if26 on 18/12/12.
//  Copyright (c) 2012 com.utt.if26. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <MapKit/MKAnnotation.h>
#import <CoreLocation/CoreLocation.h>
#import "Annotation.h"

@interface UserViewController : UIViewController <MKMapViewDelegate, UISearchBarDelegate> {
    IBOutlet MKMapView* mapView;
    BOOL isUpdatingRoutes;
}

//Liste d'amis de l'utilisateur
@property (nonatomic, retain) NSMutableArray* friendsList;
@property (nonatomic, retain) IBOutlet MKMapView* mapView;
@property (retain, nonatomic) IBOutlet UISearchBar *searchFriend;
@property (nonatomic, retain) NSArray* routes;

- (IBAction)setMap:(id)sender;
- (IBAction)menuClicked:(id)sender;
- (void) showItinerary: (Annotation*) f to: (Annotation*) t;

@end
