//
//  NSData+Base64.h
//  Roads
//
//  Created by if26 on 10/01/13.
//  Copyright (c) 2013 com.utt.if26. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSData (Base64)

+ (NSData *)dataWithBase64EncodedString:(NSString *)string;
- (NSString *)base64EncodedStringWithWrapWidth:(NSUInteger)wrapWidth;
- (NSString *)base64EncodedString;

@end
