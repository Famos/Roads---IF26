//
//  ViewController.m
//  Roads
//
//  Created by if26 on 18/12/12.
//  Copyright (c) 2012 com.utt.if26. All rights reserved.
//

#import "ViewController.h"
#import "SendPostRequestFunction.h"
#import "UserViewController.h"
#import "User.h"
#import "ErrorNetworkViewController.h"
#import "DatabaseController.h"

@implementation ViewController
@synthesize username, password, errorPrint;

- (void)viewDidLoad
{
    //[super viewDidLoad];
}

//Entrer directement dans la section ou non s'il y a quelque chose déchiffrable dans cette base.
- (void)viewDidAppear:(BOOL)animated {
    //Charger la base de données locale
    DatabaseController* databaseController = [[DatabaseController alloc]init];
    [databaseController createOrOpenDB];
    [databaseController getUser];
    User* user = [User getInstance];
    NSLog(@"name of user in loca database = %@", [user login]);
    
    if([user login]) {
        //Entrer directement dans la page UserViewController
        NSMutableDictionary* dictParams = [[NSMutableDictionary alloc] init];
        NSString *escapedString = (NSString *)CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(
                                                                                                        NULL,
                                                                                                        (__bridge CFStringRef) [user login],
                                                                                                        NULL,
                                                                                                        (CFStringRef)@"!*'();:@&=+$,/?%#[]",
                                                                                                        kCFStringEncodingUTF8));
        [dictParams setObject: escapedString forKey:@"login"];
        //Créer la requête d'authentification et obtenir la réponse
        NSString* sUserJson = [SendPostRequestFunction postRequest:dictParams withUrl:@"http://localhost:8888/authentification_automatique.php"];
        if(sUserJson == nil) {
            UIStoryboard* mainStoryBoard = self.storyboard;
            ErrorNetworkViewController* errorNetworkViewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"networkError"];
            [self presentViewController:errorNetworkViewController animated:YES completion:nil];
            return;
        } else {
            NSError* error = nil;
            NSData* jsonData = [sUserJson dataUsingEncoding:NSUTF8StringEncoding];
            id oUserObject = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];
            if([oUserObject isKindOfClass:[NSDictionary class]]) {
                NSDictionary* oUser = (NSDictionary*) oUserObject;
                
                NSString* token = [oUser valueForKey:@"TOKEN"];
                NSString* login = [oUser valueForKey:@"LOGIN"];
                [user setToken:token];
                [user setLogin:login];
                
                UIStoryboard* mainStoryBoard = self.storyboard;
                UserViewController* userViewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"userViewController"];
                [self presentViewController:userViewController animated:YES completion:nil];
            }
        } 
    } else {
        //Pas de connexion avant
        NSLog(@"no user in local database = %@", [user login]);
        [super viewDidLoad];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    [self setUsername:nil];
    [self setPassword:nil];
    [self setErrorPrint:nil];
    [super viewDidUnload];
}

//Bouton d'authentification
- (IBAction)btnAuthClicked:(id)sender {
    NSString* sUsername = [username text];
    NSString* sPassword = [password text];
    
    //Faire appel à la requête d'authentification
    [self authentificationRequest: username:sUsername andPass:sPassword];
}

//La requête d'authentification
- (void)authentificationRequest: username:(NSString*)sUsername andPass: (NSString*) sPassword {
    //Créer un objet NSMutableDictionary contenant des données à envoyer au serveur
    NSMutableDictionary* dictParams = [[NSMutableDictionary alloc] init];
    //NSLog(@"sUsername = %@", sUsername);
    //NSLog(@"sPassword = %@", sPassword);
    [dictParams setObject:sUsername forKey:@"login"];
    [dictParams setObject:sPassword forKey:@"password"];
    
    //Créer la requête d'authentification et obtenir la réponse
    NSString* sUserJson = [SendPostRequestFunction postRequest:dictParams withUrl:@"http://localhost:8888/authentification.php"];
    if(sUserJson == nil) {
        UIStoryboard* mainStoryBoard = self.storyboard;
        ErrorNetworkViewController* errorNetworkViewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"networkError"];
        [self presentViewController:errorNetworkViewController animated:YES completion:nil];
        return;
    } else {
        //Afficher le résultat sous forme de JSON pour pouvoir vérifier
        NSLog(@"sUserJson = %@",sUserJson);
        
        //Analyser le contenu du JSON reçu
        NSError* error = nil;
        NSData* jsonData = [sUserJson dataUsingEncoding:NSUTF8StringEncoding];
        id oUserObject = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];
        if([oUserObject isKindOfClass:[NSDictionary class]]) {
            NSDictionary* oUser = (NSDictionary*) oUserObject;
            
            //Affecter les valeurs à un seul objet unique
            //int ID = [[oUser valueForKey:@"ID"] intValue];
            NSString* token = [oUser valueForKey:@"TOKEN"];
            //NSString* expiration = [oUser valueForKey:@"EXPIRATION"];
            NSString* login = [oUser valueForKey:@"LOGIN"];
            NSString* message = [oUser valueForKey:@"MESSAGE"];
            int erreur = [[oUser valueForKey:@"ERREUR"] intValue];
            
            //Tester si l'authentification est réussie ou échec
            if(erreur == 0) {
                User* user = [User getInstance];
                //[user setID:ID];
                [user setToken:token];
                //[user setExpiration:expiration];
                [user setLogin:login];
                [user setErreur:erreur];
                //NSLog(@"ID = %d",[user ID]);
                //NSLog(@"token = %@", [user token]);
                //NSLog(@"expiration = %@", [user expiration]);
                //NSLog(@"login = %@", [user login]);
                //NSLog(@"erreur = %d", [user erreur]);
                //NSLog(@"latitude = %f", [user latitude]);
                
                //Passer à la vue principale
                DatabaseController* databaseController = [[DatabaseController alloc]init];
                [databaseController createOrOpenDB];
                [databaseController addUser];
                
                
                UIStoryboard* mainStoryBoard = self.storyboard;
                UserViewController* userViewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"userViewController"];
                [self presentViewController:userViewController animated:YES completion:nil];
                
                //Envoyer une requête pour mettre à jour la position courante sur la base de données à distance
                NSMutableDictionary* dictParams = [[NSMutableDictionary alloc] init];
                [dictParams setObject:[user login] forKey:@"login"];
                [dictParams setObject:[user token] forKey:@"token"];
                [dictParams setObject:[NSString stringWithFormat:@"%f",[user latitude]] forKey:@"latitude"];
                [dictParams setObject:[NSString stringWithFormat:@"%f",[user longitude]] forKey:@"longitude"];
                NSString* sUserJson = [SendPostRequestFunction postRequest:dictParams withUrl:@"http://localhost:8888/mise_a_jour_position.php"];
                //NSLog(@"sUserJson = %@",sUserJson);
                
                //Vérifier au niveau du token
                NSError* error = nil;
                NSData* jsonData = [sUserJson dataUsingEncoding:NSUTF8StringEncoding];
                id jsonDataObject = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];
                if([jsonDataObject isKindOfClass:[NSDictionary class]]) {
                    NSDictionary* data = (NSDictionary*) jsonDataObject;
                    int erreur = [[data valueForKey:@"ERREUR"] intValue];
                    if(erreur == -1) {
                        DatabaseController* databaseController = [[DatabaseController alloc]init];
                        [databaseController createOrOpenDB];
                        [databaseController deleteUser];
                        
                        //Retourner ver l'interface d'authentification
                        UIStoryboard* mainStoryBoard = self.storyboard;
                        ViewController* viewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"viewController"];
                        [self presentViewController:viewController animated:YES completion:nil];
                    }
                    return;
                }
            } else if(erreur == 3) {
                [errorPrint setText:message];
            }
            else if(erreur == 4) {
                [errorPrint setText:message];
            }
            else{
                [errorPrint setText:@"Identifiants sont incorrects"];
            }
        }
    }
}


@end
