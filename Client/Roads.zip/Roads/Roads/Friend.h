//
//  Friend.h
//  Roads
//
//  Created by if26 on 19/12/12.
//  Copyright (c) 2012 com.utt.if26. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Friend : NSObject {
    
}

@property (retain, nonatomic) NSString* friendName;
@property (atomic, assign) double friendLatitude;
@property (atomic, assign) double friendLongitude;
+ (Friend *) getInstance;

@end
