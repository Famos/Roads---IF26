//
//  UserViewController.m
//  Roads
//
//  Created by if26 on 18/12/12.
//  Copyright (c) 2012 com.utt.if26. All rights reserved.
//

#import "UserViewController.h"
#import "Annotation.h"
#import "User.h"
#import "OptionsViewController.h"
#import "FriendViewController.h"
#import "Friend.h"
#import "FriendsViewController.h"
#import "SendPostRequestFunction.h"
#import "AddNewFriendViewController.h"

@implementation UserViewController

@synthesize mapView,searchFriend;
@synthesize routes;
@synthesize friendsList;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //Définir l'action de recherche
    self.searchFriend.delegate = self;
    
    //Définir la position courante et lui affecter une annotation
    [mapView setZoomEnabled:YES];
    [mapView setScrollEnabled:YES];
    [mapView setDelegate:self];
    
    //Récupérer la liste d'amis de l'utilisateur
    User* user = [User getInstance];
    NSMutableDictionary* dictParams = [[NSMutableDictionary alloc] init];
    [dictParams setObject:[user login] forKey:@"login"];
    NSString* friendsJson = [SendPostRequestFunction postRequest:dictParams withUrl:@"http://localhost:8888/affichage_amis.php"];
    if(friendsJson != nil) {
        NSError* error = nil;
        NSData* jsonData = [friendsJson dataUsingEncoding:NSUTF8StringEncoding];
        id friendsListObject = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];
        if([friendsListObject isKindOfClass: [NSMutableArray class]]) {
            self.friendsList = (NSMutableArray*) friendsListObject;
        }
    }
    
    
    MKCoordinateRegion myRegion;
    CLLocationCoordinate2D center;
    center.latitude = 48.858850;
    center.longitude = 2.55279;
    MKCoordinateSpan span;
    span.latitudeDelta = 0.2f;
    span.longitudeDelta = 0.2f;
    myRegion.center = center;
    myRegion.span = span;
    [mapView setRegion:myRegion animated:YES];
    
    /*
    NSMutableArray* locations = [[NSMutableArray alloc] init];
    CLLocationCoordinate2D location;
    Annotation* annotation;
    for(NSMutableDictionary* friendJSONObject in self.friendsList) {
        NSLog(@"abc = %f", [[friendJSONObject valueForKey:@"LATITUDE"] doubleValue]);
        NSLog(@"def = %f", [[friendJSONObject valueForKey:@"LONGITUDE"] doubleValue]);
        location.longitude = [[friendJSONObject valueForKey:@"LATITUDE"] doubleValue];
        location.longitude = [[friendJSONObject valueForKey:@"LONGITUDE"] doubleValue];
        annotation = [[Annotation alloc] init];
        annotation.coordinate = location;
        annotation.title = [friendJSONObject valueForKey:@"LOGIN"];
        [locations addObject:annotation];
    }
    NSLog(@"taille = %d", [locations count]);
    */
    
    //Il faut récupérer la position courante de l'utilisateur pour pouvoir mettre à jour la base de données
    [user setLatitude:48.858991];
    [user setLongitude:2.55279];
    
    
    //Premier point
    MKCoordinateRegion trungParis;
    trungParis.span.latitudeDelta = 0.3f;
    trungParis.span.longitudeDelta = 0.3f;
    trungParis.center.latitude = 48.858991;
    trungParis.center.longitude = 2.35279;
    
    Annotation* annotationParis = [[Annotation alloc] init];
    annotationParis.title = @"Exemple 1";
    annotationParis.coordinate = trungParis.center;
    [mapView addAnnotation:annotationParis];
     
    //Deuxième point
    MKCoordinateRegion antoineParis;
    antoineParis.span.latitudeDelta = 0.3f;
    antoineParis.span.longitudeDelta = 0.3f;
    antoineParis.center.latitude = 48.958900;
    antoineParis.center.longitude = 2.55279;
    //[mapView setRegion:antoineParis animated:YES];
    
    Annotation* annotationAntoineParis = [[Annotation alloc] init];
    annotationAntoineParis.title = @"Exemple 2";
    annotationAntoineParis.coordinate = antoineParis.center;
    [mapView addAnnotation:annotationAntoineParis];
    
    //Définir l'itinéraire
    [self showItinerary:annotationParis to:annotationAntoineParis];
}

- (void) showItinerary: (Annotation*) f to: (Annotation*) t {
    self.routes = [self calculateRoutesFrom:f.coordinate to:t.coordinate];
    NSInteger numberOfSteps = routes.count;
    
    CLLocationCoordinate2D coordinates[numberOfSteps];
    for (NSInteger index = 0; index < numberOfSteps; index++)
    {
        CLLocation *location = [routes objectAtIndex:index];
        CLLocationCoordinate2D coordinate = location.coordinate;
        coordinates[index] = coordinate;
    }
    MKPolyline *polyLine = [MKPolyline polylineWithCoordinates:coordinates count:numberOfSteps];
    [mapView addOverlay:polyLine];;
    [self centerMap];
}

- (void) centerMap
{
    MKCoordinateRegion region;
    CLLocationDegrees maxLat = -90.0;
    CLLocationDegrees maxLon = -180.0;
    CLLocationDegrees minLat = 90.0;
    CLLocationDegrees minLon = 180.0;
    for(int idx = 0; idx < routes.count; idx++)
    {
        CLLocation* currentLocation = [routes objectAtIndex:idx];
        if(currentLocation.coordinate.latitude > maxLat)
            maxLat = currentLocation.coordinate.latitude;
        if(currentLocation.coordinate.latitude < minLat)
            minLat = currentLocation.coordinate.latitude;
        if(currentLocation.coordinate.longitude > maxLon)
            maxLon = currentLocation.coordinate.longitude;
        if(currentLocation.coordinate.longitude < minLon)
            minLon = currentLocation.coordinate.longitude;
    }
    region.center.latitude     = (maxLat + minLat) / 2.0;
    region.center.longitude    = (maxLon + minLon) / 2.0;
    region.span.latitudeDelta = 0.01;
    region.span.longitudeDelta = 0.01;
    
    region.span.latitudeDelta  = ((maxLat - minLat)<0.0)?100.0:(maxLat - minLat);
    region.span.longitudeDelta = ((maxLon - minLon)<0.0)?100.0:(maxLon - minLon);
    [mapView setRegion:region animated:YES];
}

- (NSArray*) calculateRoutesFrom:(CLLocationCoordinate2D) f to: (CLLocationCoordinate2D) t
{
    NSString* saddr = [NSString stringWithFormat:@"%f,%f", f.latitude, f.longitude];
    NSString* daddr = [NSString stringWithFormat:@"%f,%f", t.latitude, t.longitude];
    
    NSString* apiUrlStr = [NSString stringWithFormat:@"http://maps.google.com/maps?output=dragdir&saddr=%@&daddr=%@", saddr, daddr];
    NSURL* apiUrl = [NSURL URLWithString:apiUrlStr];
    NSError* error = nil;
    NSString *apiResponse = [NSString stringWithContentsOfURL:apiUrl encoding:NSASCIIStringEncoding error:&error];
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"points:\\\"([^\\\"]*)\\\"" options:0 error:NULL];
    NSTextCheckingResult *match = [regex firstMatchInString:apiResponse options:0 range:NSMakeRange(0, [apiResponse length])];
    NSString *encodedPoints = [apiResponse substringWithRange:[match rangeAtIndex:1]];
    
    return [self decodePolyLine:[encodedPoints mutableCopy]];
}

- (NSMutableArray *)decodePolyLine: (NSMutableString *)encoded
{
    [encoded replaceOccurrencesOfString:@"\\\\" withString:@"\\" options:NSLiteralSearch range:NSMakeRange(0, [encoded length])];
    NSInteger len = [encoded length];
    NSInteger index = 0;
    NSMutableArray *array = [[NSMutableArray alloc] init];
    NSInteger lat=0;
    NSInteger lng=0;
    while (index < len)
    {
        NSInteger b;
        NSInteger shift = 0;
        NSInteger result = 0;
        do
        {
            b = [encoded characterAtIndex:index++] - 63;
            result |= (b & 0x1f) << shift;
            shift += 5;
        } while (b >= 0x20);
        NSInteger dlat = ((result & 1) ? ~(result >> 1) : (result >> 1));
        lat += dlat;
        shift = 0;
        result = 0;
        do
        {
            b = [encoded characterAtIndex:index++] - 63;
            result |= (b & 0x1f) << shift;
            shift += 5;
        } while (b >= 0x20);
        NSInteger dlng = ((result & 1) ? ~(result >> 1) : (result >> 1));
        lng += dlng;
        NSNumber *latitude = [[NSNumber alloc] initWithFloat:lat * 1e-5];
        NSNumber *longitude = [[NSNumber alloc] initWithFloat:lng * 1e-5];
        //printf("[%f,", [latitude doubleValue]);
        //printf("%f]", [longitude doubleValue]);
        CLLocation *loc = [[CLLocation alloc] initWithLatitude:[latitude floatValue] longitude:[longitude floatValue]];
        [array addObject:loc];
    }
    return array;
}

- (MKOverlayView *)mapView:(MKMapView *)mapView viewForOverlay:(id <MKOverlay>)overlay
{
    MKPolylineView *polylineView = [[MKPolylineView alloc] initWithPolyline:overlay];
    polylineView.strokeColor = [UIColor purpleColor];
    polylineView.lineWidth = 2.0;
    return polylineView;
}

//Définir l'action de recherche
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    User* user = [User getInstance];
    NSMutableDictionary* dictParams = [[NSMutableDictionary alloc] init];
    [dictParams setObject:[user login] forKey:@"login"];
    [dictParams setObject:searchBar.text forKey:@"ami"];
    NSString* addFriend = [SendPostRequestFunction postRequest:dictParams withUrl:@"http://localhost:8888/test_ami.php"];
    
    NSError* error = nil;
    NSData* jsonData = [addFriend dataUsingEncoding:NSUTF8StringEncoding];
    id returnJSONObject = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];
    if([returnJSONObject isKindOfClass:[NSDictionary class]]) {
        NSDictionary* returnJSON = (NSDictionary*) returnJSONObject;
        int code = [[returnJSON valueForKey:@"CODE"] intValue];
        NSLog(@"$code = %d", code);
        if(code == 1) {
            Friend* friend = [Friend getInstance];
            [friend setFriendName:searchBar.text];
            UIStoryboard* mainStoryBoard = self.storyboard;
            AddNewFriendViewController* addNewFriendViewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"addNewFriendViewController"];
            [self presentViewController:addNewFriendViewController animated:YES completion:nil];
        }
        else if (code == 2){
            UIAlertView *alert = [[UIAlertView alloc]
                                  initWithTitle:@""
                                  message:[NSString stringWithFormat:@"L'utilisateur %@ n'existe pas !",searchBar.text]
                                  delegate:nil
                                  cancelButtonTitle:@"OK"
                                  otherButtonTitles:nil];
            [alert show];
        }
        else if (code == 3){
            //Passer à la vue d'un ami
            UIStoryboard* mainStoryBoard = self.storyboard;
            FriendViewController* friendViewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"friendViewController"];
            [friendViewController setReturnButton:1];
            Friend* friend = [Friend getInstance];
            [friend setFriendName:searchBar.text];
            [self presentViewController:friendViewController animated:YES completion:nil];
        }
    }
}

//Définir la représentation des annotations
- (MKAnnotationView*) mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation {
    MKPinAnnotationView* myPin = [[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"current"];
    myPin.pinColor = MKPinAnnotationColorRed;
    
    UIButton* advertButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
    [advertButton addTarget:self action:@selector(button:) forControlEvents:UIControlEventTouchUpInside];
    
    myPin.rightCalloutAccessoryView = advertButton;
    myPin.draggable = NO;
    myPin.highlighted = YES;
    myPin.animatesDrop = TRUE;
    myPin.canShowCallout = YES;
    
    return myPin;
}

//Définir ce que l'annotation fait quand c'est cliqué
- (void)button:(id)sender {
    NSLog(@"Button action");
}

//Définir les options d'affichage de la carte
- (IBAction)setMap:(id)sender {
    switch (((UISegmentedControl*) sender).selectedSegmentIndex) {
        case 0:
            mapView.mapType = MKMapTypeStandard;
            break;
        case 1:
            mapView.mapType = MKMapTypeSatellite;
            break;
        case 2:
            mapView.mapType = MKMapTypeHybrid;
            break;
    }
}

//Définir des actions qui seront effectuées quand on clique sur les boutons "Amis" ou "Opions"
- (IBAction)menuClicked:(id)sender {
    UIStoryboard* mainStoryBoard = self.storyboard;
    switch (((UISegmentedControl*)sender).selectedSegmentIndex) {
        case 0: {
            //Bouton "Amis" cliqué
            FriendsViewController* friendsViewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"friendsViewController"];
            [self presentViewController:friendsViewController animated:YES completion:nil];
        }   
            break;
            
        case 1: {
            //Bouton "Options" cliqué
            OptionsViewController* optionsViewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"options"];
            [self presentViewController:optionsViewController animated:YES completion:nil];
        }
            break;
    }
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)viewDidUnload {
    [self setSearchFriend:nil];
    [super viewDidUnload];
}
@end
