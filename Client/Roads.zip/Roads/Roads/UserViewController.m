//
//  UserViewController.m
//  Roads
//
//  Created by if26 on 18/12/12.
//  Copyright (c) 2012 com.utt.if26. All rights reserved.
//

#import "UserViewController.h"
#import "MyAnnotation.h"
#import "User.h"
#import "OptionsViewController.h"
#import "FriendViewController.h"
#import "Friend.h"
#import "FriendsViewController.h"
#import "SendPostRequestFunction.h"
#import "AddNewFriendViewController.h"


#import <Foundation/Foundation.h>
#import "NSData+AES.h"
#import "NSData+Base64.h"
#import "NSString+Base64.h"


@implementation UserViewController

@synthesize myMapView,searchFriend;
@synthesize routes;
@synthesize friendsList;
@synthesize isItinerary;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.isItinerary = 0;
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    NSLog(@"isItinerary = %d", self.isItinerary);
    //Définir l'action de recherche
    self.searchFriend.delegate = self;
    
    //Définir la position courante et lui affecter une annotation
    [myMapView setZoomEnabled:YES];
    [myMapView setScrollEnabled:YES];
    [myMapView setDelegate:self];
    
    //Récupérer la liste d'amis de l'utilisateur
    User* user = [User getInstance];
    NSMutableDictionary* dictParams = [[NSMutableDictionary alloc] init];
    [dictParams setObject:[user login] forKey:@"login"];
    NSString* friendsJson = [SendPostRequestFunction postRequest:dictParams withUrl:@"http://localhost:8888/affichage_amis.php"];
    if(friendsJson != nil) {
        NSError* error = nil;
        NSData* jsonData = [friendsJson dataUsingEncoding:NSUTF8StringEncoding];
        id friendsListObject = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];
        if([friendsListObject isKindOfClass: [NSMutableArray class]]) {
            self.friendsList = (NSMutableArray*) friendsListObject;
        }
    }
    NSLog(@"nombre amis = %d",[self.friendsList count]);
    
    //Préparer la map (s'il n'y a pas d'itinéraire, on affecte la map par ces valeurs)
    CLLocationCoordinate2D center = {48.858850,2.55279};
    MKCoordinateSpan span = MKCoordinateSpanMake(0.2f,0.2f);
    MKCoordinateRegion myRegion = MKCoordinateRegionMake(center, span);
    [myMapView setRegion:myRegion animated:YES];
    [myMapView regionThatFits:myRegion];
    
    //FIXME : Il faut récupérer la position courante de l'utilisateur pour pouvoir mettre à jour la base de données
    [user setLatitude:48.858991];
    [user setLongitude:2.35279];
    
    //Afficher les annotations sur la carte
    MKCoordinateRegion coordinateRegion;
    MyAnnotation* oneAnnotation;
    //Préparer les annotations des amis
    NSMutableArray* locationsFriends = [[NSMutableArray alloc] initWithCapacity:0];
    for(NSMutableDictionary* friendJSONObject in self.friendsList) {
        coordinateRegion.center.latitude = [[friendJSONObject valueForKey:@"LATITUDE"] doubleValue];
        coordinateRegion.center.longitude = [[friendJSONObject valueForKey:@"LONGITUDE"] doubleValue];
        //NSLog(@"latitude = %f", coordinateRegion.center.latitude);
        //NSLog(@"longitude = %f", coordinateRegion.center.longitude);
        //NSLog(@"name ami = %@", [friendJSONObject valueForKey:@"LOGIN"]);
        oneAnnotation = [[MyAnnotation alloc] init];
        oneAnnotation.coordinate = coordinateRegion.center;
        oneAnnotation.title = [[friendJSONObject valueForKey:@"LOGIN"] stringByReplacingCharactersInRange:NSMakeRange(0,1) withString:[[[friendJSONObject valueForKey:@"LOGIN"] substringToIndex:1] uppercaseString]];
        [locationsFriends addObject:oneAnnotation];
     }
    [myMapView addAnnotations:locationsFriends];
    
    //Afficher la position courante de l'utilisateur
    coordinateRegion.center.latitude = [user latitude];
    coordinateRegion.center.longitude = [user longitude];
    NSLog(@"latitude moi= %f", coordinateRegion.center.latitude);
    NSLog(@"longitude moi= %f", coordinateRegion.center.longitude);
    MyAnnotation* myAnnotation = [[MyAnnotation alloc] init];
    //oneAnnotation.title = [[user login] stringByReplacingCharactersInRange:NSMakeRange(0,1) withString:[[[user login] substringToIndex:1] uppercaseString]];
    myAnnotation.title = @"Moi";
    myAnnotation.coordinate = coordinateRegion.center;
    [myMapView addAnnotation:myAnnotation];
    
    //Définir l'itinéraire s'il il y a une demande
    //[self showItinerary:annotationParis to:annotationAntoineParis];
    if (self.isItinerary == 1) {
        Friend* friend = [Friend getInstance];
        coordinateRegion.center.latitude = [friend friendLatitude];
        coordinateRegion.center.longitude = [friend friendLongitude];
        NSLog(@"friend = %f et %f", [friend friendLatitude], [friend friendLongitude] );
        MyAnnotation* friendAnnotation = [[MyAnnotation alloc] init];
        friendAnnotation.title = [[friend friendName] stringByReplacingCharactersInRange:NSMakeRange(0,1) withString:[[[friend friendName] substringToIndex:1] uppercaseString]];
        friendAnnotation.coordinate = coordinateRegion.center;
        [myMapView addAnnotation:friendAnnotation];
        [self showItinerary:myAnnotation to:friendAnnotation];
        //NSLog(@"vient de Firend view controller");
    }
}

//Fonction permettant d'afficher l'itinéraire entre deux point
- (void) showItinerary: (MyAnnotation*) f to: (MyAnnotation*) t {
    self.routes = [self calculateRoutesFrom:f.coordinate to:t.coordinate];
    NSInteger numberOfSteps = routes.count;
    
    CLLocationCoordinate2D coordinates[numberOfSteps];
    for (NSInteger index = 0; index < numberOfSteps; index++)
    {
        CLLocation *location = [routes objectAtIndex:index];
        CLLocationCoordinate2D coordinate = location.coordinate;
        coordinates[index] = coordinate;
    }
    MKPolyline *polyLine = [MKPolyline polylineWithCoordinates:coordinates count:numberOfSteps];
    [myMapView addOverlay:polyLine];;
    [self centerMap];
}

- (void) centerMap
{
    MKCoordinateRegion region;
    CLLocationDegrees maxLat = -90.0;
    CLLocationDegrees maxLon = -180.0;
    CLLocationDegrees minLat = 90.0;
    CLLocationDegrees minLon = 180.0;
    for(int idx = 0; idx < routes.count; idx++)
    {
        CLLocation* currentLocation = [routes objectAtIndex:idx];
        if(currentLocation.coordinate.latitude > maxLat)
            maxLat = currentLocation.coordinate.latitude;
        if(currentLocation.coordinate.latitude < minLat)
            minLat = currentLocation.coordinate.latitude;
        if(currentLocation.coordinate.longitude > maxLon)
            maxLon = currentLocation.coordinate.longitude;
        if(currentLocation.coordinate.longitude < minLon)
            minLon = currentLocation.coordinate.longitude;
    }
    region.center.latitude     = (maxLat + minLat) / 2.0;
    region.center.longitude    = (maxLon + minLon) / 2.0;
    region.span.latitudeDelta = 0.01;
    region.span.longitudeDelta = 0.01;
    
    region.span.latitudeDelta  = ((maxLat - minLat)<0.0)?100.0:(maxLat - minLat);
    region.span.longitudeDelta = ((maxLon - minLon)<0.0)?100.0:(maxLon - minLon);
    [myMapView setRegion:region animated:YES];
}

- (NSArray*) calculateRoutesFrom:(CLLocationCoordinate2D) f to: (CLLocationCoordinate2D) t
{
    NSString* saddr = [NSString stringWithFormat:@"%f,%f", f.latitude, f.longitude];
    NSString* daddr = [NSString stringWithFormat:@"%f,%f", t.latitude, t.longitude];
    
    NSString* apiUrlStr = [NSString stringWithFormat:@"http://maps.google.com/maps?output=dragdir&saddr=%@&daddr=%@", saddr, daddr];
    NSURL* apiUrl = [NSURL URLWithString:apiUrlStr];
    NSError* error = nil;
    NSString *apiResponse = [NSString stringWithContentsOfURL:apiUrl encoding:NSASCIIStringEncoding error:&error];
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"points:\\\"([^\\\"]*)\\\"" options:0 error:NULL];
    NSTextCheckingResult *match = [regex firstMatchInString:apiResponse options:0 range:NSMakeRange(0, [apiResponse length])];
    NSString *encodedPoints = [apiResponse substringWithRange:[match rangeAtIndex:1]];
    
    return [self decodePolyLine:[encodedPoints mutableCopy]];
}

- (NSMutableArray *)decodePolyLine: (NSMutableString *)encoded
{
    [encoded replaceOccurrencesOfString:@"\\\\" withString:@"\\" options:NSLiteralSearch range:NSMakeRange(0, [encoded length])];
    NSInteger len = [encoded length];
    NSInteger index = 0;
    NSMutableArray *array = [[NSMutableArray alloc] init];
    NSInteger lat=0;
    NSInteger lng=0;
    while (index < len)
    {
        NSInteger b;
        NSInteger shift = 0;
        NSInteger result = 0;
        do
        {
            b = [encoded characterAtIndex:index++] - 63;
            result |= (b & 0x1f) << shift;
            shift += 5;
        } while (b >= 0x20);
        NSInteger dlat = ((result & 1) ? ~(result >> 1) : (result >> 1));
        lat += dlat;
        shift = 0;
        result = 0;
        do
        {
            b = [encoded characterAtIndex:index++] - 63;
            result |= (b & 0x1f) << shift;
            shift += 5;
        } while (b >= 0x20);
        NSInteger dlng = ((result & 1) ? ~(result >> 1) : (result >> 1));
        lng += dlng;
        NSNumber *latitude = [[NSNumber alloc] initWithFloat:lat * 1e-5];
        NSNumber *longitude = [[NSNumber alloc] initWithFloat:lng * 1e-5];
        //printf("[%f,", [latitude doubleValue]);
        //printf("%f]", [longitude doubleValue]);
        CLLocation *loc = [[CLLocation alloc] initWithLatitude:[latitude floatValue] longitude:[longitude floatValue]];
        [array addObject:loc];
    }
    return array;
}


- (MKOverlayView *)mapView:(MKMapView *)mapView viewForOverlay:(id <MKOverlay>)overlay
{
    MKPolylineView *polylineView = [[MKPolylineView alloc] initWithPolyline:overlay];
    polylineView.strokeColor = [UIColor purpleColor];
    polylineView.lineWidth = 1.0;
    return polylineView;
}

//Définir l'action de recherche
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    User* user = [User getInstance];
    NSMutableDictionary* dictParams = [[NSMutableDictionary alloc] init];
    [dictParams setObject:[user login] forKey:@"login"];
    [dictParams setObject:searchBar.text forKey:@"ami"];
    NSString* addFriend = [SendPostRequestFunction postRequest:dictParams withUrl:@"http://localhost:8888/test_ami.php"];
    
    NSError* error = nil;
    NSData* jsonData = [addFriend dataUsingEncoding:NSUTF8StringEncoding];
    id returnJSONObject = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];
    if([returnJSONObject isKindOfClass:[NSDictionary class]]) {
        NSDictionary* returnJSON = (NSDictionary*) returnJSONObject;
        int code = [[returnJSON valueForKey:@"CODE"] intValue];
        NSLog(@"$code = %d", code);
        if(code == 1) {
            Friend* friend = [Friend getInstance];
            [friend setFriendName:searchBar.text];
            UIStoryboard* mainStoryBoard = self.storyboard;
            AddNewFriendViewController* addNewFriendViewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"addNewFriendViewController"];
            [self presentViewController:addNewFriendViewController animated:YES completion:nil];
        }
        else if (code == 2){
            UIAlertView *alert = [[UIAlertView alloc]
                                  initWithTitle:@""
                                  message:[NSString stringWithFormat:@"L'utilisateur %@ n'existe pas !",searchBar.text]
                                  delegate:nil
                                  cancelButtonTitle:@"OK"
                                  otherButtonTitles:nil];
            [alert show];
        }
        else if (code == 3){
            //Passer à la vue d'un ami
            UIStoryboard* mainStoryBoard = self.storyboard;
            FriendViewController* friendViewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"friendViewController"];
            [friendViewController setReturnButton:1];
            Friend* friend = [Friend getInstance];
            [friend setFriendName:searchBar.text];
            [self presentViewController:friendViewController animated:YES completion:nil];
        }
    }
}

//Définir la représentation des annotations
- (MKAnnotationView*) mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation {
    MKPinAnnotationView* myPin = [[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"current"];
    
    if([annotation title] != @"Moi") {
        myPin.pinColor = MKPinAnnotationColorRed;
        UIButton* advertButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
        //Pour retrouver le nom de l'ami
        advertButton.accessibilityHint = [annotation title];
        [advertButton addTarget:self action:@selector(button:) forControlEvents:UIControlEventTouchUpInside];
        myPin.rightCalloutAccessoryView = advertButton;
    } else {
        myPin.pinColor = MKPinAnnotationColorGreen;
    }
    myPin.draggable = NO;
    myPin.highlighted = YES;
    myPin.animatesDrop = TRUE;
    myPin.canShowCallout = YES;
    
    return myPin;
}

//Définir ce que l'annotation fait une fois c'est cliqué
- (void)button:(id)sender {
    UIButton* clicked = (UIButton*) sender;
    //NSLog(@"Button sender hint = %@", [clicked accessibilityHint]);
    
    Friend* friend = [Friend getInstance];
    [friend setFriendName:[clicked accessibilityHint]];
    UIStoryboard* mainStoryBoard = self.storyboard;
    FriendViewController* friendViewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"friendViewController"];
    [friendViewController setReturnButton:3];
    [self presentViewController:friendViewController animated:YES completion:nil];
    
    //NSLog(@"Button action");
}

//Définir les options d'affichage de la carte
- (IBAction)setMap:(id)sender {
    switch (((UISegmentedControl*) sender).selectedSegmentIndex) {
        case 0:
            myMapView.mapType = MKMapTypeStandard;
            break;
        case 1:
            myMapView.mapType = MKMapTypeSatellite;
            break;
        case 2:
            myMapView.mapType = MKMapTypeHybrid;
            break;
    }
}

//Définir des actions qui seront effectuées quand on clique sur les boutons "Amis" ou "Opions"
- (IBAction)menuClicked:(id)sender {
    UIStoryboard* mainStoryBoard = self.storyboard;
    switch (((UISegmentedControl*)sender).selectedSegmentIndex) {
        case 0: {
            //Bouton "Amis" cliqué
            FriendsViewController* friendsViewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"friendsViewController"];
            [self presentViewController:friendsViewController animated:YES completion:nil];
        }   
            break;
            
        case 1: {
            //Bouton "Options" cliqué
            OptionsViewController* optionsViewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"options"];
            [self presentViewController:optionsViewController animated:YES completion:nil];
        }
            break;
    }
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)viewDidUnload {
    [self setSearchFriend:nil];
    [super viewDidUnload];
}
@end
