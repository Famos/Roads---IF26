//
//  DatabaseController.h
//  Roads
//
//  Created by if26 on 10/01/13.
//  Copyright (c) 2013 com.utt.if26. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>

@interface DatabaseController : NSObject {
    NSString* dbPathString;
    sqlite3* localDB;
}

- (void)createOrOpenDB;
- (void)addUser;
- (void)getUser;
- (void)deleteUser;

@end
