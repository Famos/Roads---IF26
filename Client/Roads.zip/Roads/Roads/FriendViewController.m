//
//  FriendViewController.m
//  Roads
//
//  Created by if26 on 19/12/12.
//  Copyright (c) 2012 com.utt.if26. All rights reserved.
//

#import "FriendViewController.h"
#import "Friend.h"
#import "UserViewController.h"
#import "FriendsViewController.h"
#import "User.h"
#import "SendPostRequestFunction.h"

@implementation FriendViewController
@synthesize friendNameLabel;
@synthesize friendName;
@synthesize returnButton;
@synthesize changeVisibilityButton, visibilite;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    User* user = [User getInstance];
    Friend* friend = [Friend getInstance];
    
    //Récupérer les coordonnées de l'ami
    NSMutableDictionary* dictParams = [[NSMutableDictionary alloc] init];
    [dictParams setObject:[user login] forKey:@"login"];
    [dictParams setObject:[friend friendName] forKey:@"ami"];
    NSString* friendInfos = [SendPostRequestFunction postRequest:dictParams withUrl:@"http://localhost:8888/affichage_ami.php"];
    
    NSError* error = nil;
    NSData* jsonData = [friendInfos dataUsingEncoding:NSUTF8StringEncoding];
    id returnJSONObject = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];
    if([returnJSONObject isKindOfClass:[NSDictionary class]]) {
        NSDictionary* returnJSON = (NSDictionary*) returnJSONObject;
        
        [friend setFriendLatitude: [[returnJSON valueForKey:@"LATITUDE"] doubleValue]]; 
        [friend setFriendLongitude: [[returnJSON valueForKey:@"LONGITUDE"] doubleValue]];
        NSLog(@"friend latitude view did load = %f",[[returnJSON valueForKey:@"LATITUDE"] doubleValue]);
    }
    
    //Initialiser le bouton de change de visibilité
    self.visibilite = [self testFriend];
    UIControlState* uiControlState = nil;
    if(visibilite == 0) {
        [self.changeVisibilityButton setTitle:@"Afficher ma position" forState:nil];
    } else {
        [self.changeVisibilityButton setTitle:@"Masquer ma position" forState:nil];
    }

    self.friendNameLabel.text = [[friend friendName] stringByReplacingCharactersInRange:NSMakeRange(0,1) withString:[[[friend friendName] substringToIndex:1] uppercaseString]];
    self.friendName = [friend friendName];
	// Do any additional setup after loading the view.
}

- (int) testFriend {
    int visibiliteLocal = 0;
    User* user = [User getInstance];
    Friend* friend = [Friend getInstance];
    NSMutableDictionary* dictParams = [[NSMutableDictionary alloc] init];
    [dictParams setObject:[user login] forKey:@"login"];
    [dictParams setObject:[friend friendName] forKey:@"ami"];
    NSString* testFriend = [SendPostRequestFunction postRequest:dictParams withUrl:@"http://localhost:8888/test_position_ami.php"];
    
    NSError* error = nil;
    NSData* jsonData = [testFriend dataUsingEncoding:NSUTF8StringEncoding];
    id returnJSONObject = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];
    if([returnJSONObject isKindOfClass:[NSDictionary class]]) {
        NSDictionary* returnJSON = (NSDictionary*) returnJSONObject;
        visibiliteLocal = [[returnJSON valueForKey:@"VISIBILITE"] intValue];
    }
    
    return visibiliteLocal;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    [self setFriendName:nil];
    [self setChangeVisibilityButton:nil];
    [super viewDidUnload];
}

//Centrer la carte sur la position de l'ami
- (IBAction)btnShowPositionClicked:(id)sender {
    UIStoryboard* mainStoryBoard = self.storyboard;
    UserViewController* userViewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"userViewController"];
    [self presentViewController:userViewController animated:YES completion:nil];
    
    Friend* friend = [Friend getInstance];
    MKCoordinateRegion friendRegion;
    friendRegion.span.latitudeDelta = 0.025f;
    friendRegion.span.longitudeDelta = 0.025f;
    friendRegion.center.latitude = [friend friendLatitude];
    friendRegion.center.longitude = [friend friendLongitude];
    MyAnnotation* annotationFriend = [[MyAnnotation alloc] init];
    annotationFriend.title = [friend friendName];
    annotationFriend.coordinate = friendRegion.center;
    [userViewController.myMapView addAnnotation:annotationFriend];
    [userViewController.myMapView setRegion:friendRegion animated:YES];
}

//Changer la visibilité de ma position par rapport à un ami
- (IBAction)btnChangeVisibilityClicked:(id)sender {
    NSLog(@"1");
    User* user = [User getInstance];
    NSMutableDictionary* dictParams = [[NSMutableDictionary alloc] init];
    [dictParams setObject:[user login] forKey:@"login"];
    [dictParams setObject:self.friendName forKey:@"ami"];
    NSString* changeVisibility = nil;
    if(self.visibilite == 0) {
        NSLog(@"2");
        changeVisibility = [SendPostRequestFunction postRequest:dictParams withUrl:@"http://localhost:8888/afficher_position_ami.php"];
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:@""
                              message:[NSString stringWithFormat:@"Votre position est désormais visibile pour %@ !",self.friendName]
                              delegate:nil
                              cancelButtonTitle:@"OK"
                              otherButtonTitles:nil];
        [alert show];
    } else {
        NSLog(@"2");
        changeVisibility = [SendPostRequestFunction postRequest:dictParams withUrl:@"http://localhost:8888/masquer_position_ami.php"];
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:@""
                              message:[NSString stringWithFormat:@"Votre position est désormais invisibile pour %@ !",self.friendName]
                              delegate:nil
                              cancelButtonTitle:@"OK"
                              otherButtonTitles:nil];
        [alert show];
    }
}

//Montrer une itinéraire vers cet ami
- (IBAction)btnShowItineraryClicked:(id)sender {
    User* user = [User getInstance];
    Friend* friend = [Friend getInstance];
    
    UIStoryboard* mainStoryBoard = self.storyboard;
    UserViewController* userViewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"userViewController"];
    [userViewController setIsItinerary:1];
    [self presentViewController:userViewController animated:YES completion:nil];
}

//Supprimer un ami
- (IBAction)btnDeleteFriendClicked:(id)sender {
    User* user = [User getInstance];
    NSMutableDictionary* dictParams = [[NSMutableDictionary alloc] init];
    [dictParams setObject:[user login] forKey:@"login"];
    [dictParams setObject:self.friendName forKey:@"ami"];
    NSString* deleteFriend = [SendPostRequestFunction postRequest:dictParams withUrl:@"http://localhost:8888/suppression_ami.php"];
    
    NSError* error = nil;
    NSData* jsonData = [deleteFriend dataUsingEncoding:NSUTF8StringEncoding];
    id returnJSONObject = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];
    if([returnJSONObject isKindOfClass:[NSDictionary class]]) {
        NSDictionary* returnJSON = (NSDictionary*) returnJSONObject;
        int erreur = [[returnJSON valueForKey:@"ERREUR"] intValue];
        NSLog(@"erreur = %d", erreur);
        UIStoryboard* mainStoryBoard = self.storyboard;
        FriendsViewController* friendsViewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"friendsViewController"];
        [self presentViewController:friendsViewController animated:YES completion:nil];
    }
}

//Déterminer d'ou on vient
- (IBAction)btnReturnClicked:(id)sender {
    NSLog(@"returnButton = %d", self.returnButton);
    if(self.returnButton == 1) {
        UIStoryboard* mainStoryBoard = self.storyboard;
        UserViewController* userViewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"userViewController"];
        [self presentViewController:userViewController animated:YES completion:nil];
    } else if(self.returnButton == 2) {
        UIStoryboard* mainStoryBoard = self.storyboard;
        FriendsViewController* friendsViewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"friendsViewController"];
        [self presentViewController:friendsViewController animated:YES completion:nil];
    } else if(self.returnButton == 3){
        UIStoryboard* mainStoryBoard = self.storyboard;
        UserViewController* userViewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"userViewController"];
        [self presentViewController:userViewController animated:YES completion:nil];
    }
}

@end
