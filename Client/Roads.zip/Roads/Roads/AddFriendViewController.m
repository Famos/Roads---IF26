//
//  AddFriendViewController.m
//  Roads
//
//  Created by if26 on 20/12/12.
//  Copyright (c) 2012 com.utt.if26. All rights reserved.
//

#import "AddFriendViewController.h"
#import "User.h"
#import "SendPostRequestFunction.h"
#import "FriendsViewController.h"

@implementation AddFriendViewController
@synthesize friendNameAdd;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    [self setFriendNameAdd:nil];
    [super viewDidUnload];
}
- (IBAction)btnAddFriendClicked:(id)sender {
    User* user = [User getInstance];
    NSMutableDictionary* dictParams = [[NSMutableDictionary alloc] init];
    [dictParams setObject:[user login] forKey:@"login"];
    [dictParams setObject:[self.friendNameAdd text] forKey:@"ami"];
    NSString* addFriend = [SendPostRequestFunction postRequest:dictParams withUrl:@"http://localhost:8888/ajout_ami.php"];
    
    NSError* error = nil;
    NSData* jsonData = [addFriend dataUsingEncoding:NSUTF8StringEncoding];
    id returnJSONObject = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];
    if([returnJSONObject isKindOfClass:[NSDictionary class]]) {
        NSDictionary* returnJSON = (NSDictionary*) returnJSONObject;
        int erreur = [[returnJSON valueForKey:@"ERREUR"] intValue];
        NSLog(@"erreur = %d", erreur);
        if(erreur == 0) {
            UIAlertView *alert = [[UIAlertView alloc]
                                                initWithTitle:@""
                                                message:[NSString stringWithFormat:@"%@ a été bien ajouté !",[self.friendNameAdd text]]
                                                delegate:nil
                                                cancelButtonTitle:@"OK"
                                                otherButtonTitles:nil];
            [alert show];
            
            UIStoryboard* mainStoryBoard = self.storyboard;
            FriendsViewController* friendsViewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"friendsViewController"];
            [self presentViewController:friendsViewController animated:YES completion:nil];
        }
        else if (erreur == 2){
            UIAlertView *alert = [[UIAlertView alloc]
                                  initWithTitle:@""
                                  message:[NSString stringWithFormat:@"L'utilisateur %@ n'existe pas !",[self.friendNameAdd text]]
                                  delegate:nil
                                  cancelButtonTitle:@"OK"
                                  otherButtonTitles:nil];
            [alert show];
        }
        else if (erreur == 3){
            UIAlertView *alert = [[UIAlertView alloc]
                                  initWithTitle:@""
                                  message:[NSString stringWithFormat:@"L'utilisateur %@ est déjà votre ami !",[self.friendNameAdd text]]
                                  delegate:nil
                                  cancelButtonTitle:@"OK"
                                  otherButtonTitles:nil];
            [alert show];
        }

    }
    
}
@end
