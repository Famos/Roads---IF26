//
//  FriendViewController.h
//  Roads
//
//  Created by if26 on 19/12/12.
//  Copyright (c) 2012 com.utt.if26. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FriendViewController : UIViewController{
    IBOutlet UILabel* friendNameLabel;
}

//Définir la façon de retourner
@property (atomic, assign) int returnButton;
@property (atomic, assign) int visibilite;
@property (retain, nonatomic) IBOutlet UILabel* friendNameLabel;
@property (retain, nonatomic) IBOutlet UIButton *changeVisibilityButton;
@property (retain, nonatomic) NSString* friendName;
- (IBAction)btnShowPositionClicked:(id)sender;
- (IBAction)btnChangeVisibilityClicked:(id)sender;
- (IBAction)btnShowItineraryClicked:(id)sender;
- (IBAction)btnDeleteFriendClicked:(id)sender;
- (IBAction)btnReturnClicked:(id)sender;
- (int) testFriend;

@end
