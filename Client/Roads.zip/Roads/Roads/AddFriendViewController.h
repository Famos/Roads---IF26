//
//  AddFriendViewController.h
//  Roads
//
//  Created by if26 on 20/12/12.
//  Copyright (c) 2012 com.utt.if26. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddFriendViewController : UIViewController

@property (retain, nonatomic) IBOutlet UITextField *friendNameAdd;

- (IBAction)btnAddFriendClicked:(id)sender;
@end
