//
//  FriendsViewController.m
//  Roads
//
//  Created by if26 on 20/12/12.
//  Copyright (c) 2012 com.utt.if26. All rights reserved.
//

#import "FriendsViewController.h"
#import "User.h"
#import "SendPostRequestFunction.h"
#import "Friend.h"
#import "FriendViewController.h"
#import "AddFriendViewController.h"


@implementation FriendsViewController
@synthesize friendsList;
@synthesize friendsListView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.friendsListView.dataSource = self;
    self.friendsListView.delegate = self;
    
    //Récupérer la liste d'amis de l'utilisateur
    User* user = [User getInstance];
    NSMutableDictionary* dictParams = [[NSMutableDictionary alloc] init];
    [dictParams setObject:[user login] forKey:@"login"];
    
    NSString* friendsJson = [SendPostRequestFunction postRequest:dictParams withUrl:@"http://localhost:8888/affichage_amis.php"];
    if(friendsJson != nil) {
        NSLog(@"friendsJson = %@",friendsJson);
        NSError* error = nil;
        NSData* jsonData = [friendsJson dataUsingEncoding:NSUTF8StringEncoding];
        id friendsListObject = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];
        if([friendsListObject isKindOfClass: [NSMutableArray class]]) {
            self.friendsList = (NSMutableArray*) friendsListObject;
        }
    }
}

- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.friendsList count];
}

- (UITableViewCell*) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString* identifier = @"identifier";
    UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        NSMutableDictionary* friend = [self.friendsList objectAtIndex:indexPath.row];
        cell.textLabel.text = [[friend valueForKey:@"LOGIN"] stringByReplacingCharactersInRange:NSMakeRange(0,1) withString:[[[friend valueForKey:@"LOGIN"] substringToIndex:1] uppercaseString]];
        [cell setAccessoryType:UITableViewCellAccessoryDetailDisclosureButton];
    }
    return cell;
}

- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    Friend* friend = [Friend getInstance];
    NSMutableDictionary* friendChosen = [self.friendsList objectAtIndex:indexPath.row];
    [friend setFriendName: [friendChosen valueForKey:@"LOGIN"]];
    UIStoryboard* mainStoryBoard = self.storyboard;
    FriendViewController* friendViewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"friendViewController"];
    [friendViewController setReturnButton:2];
    [self presentViewController:friendViewController animated:YES completion:nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//Ajouter un ami
- (IBAction)btnAddFriendClicked:(id)sender {
    UIStoryboard* mainStoryBoard = self.storyboard;
    AddFriendViewController* addFriendViewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"addFriendViewController"];
    [self presentViewController:addFriendViewController animated:YES completion:nil];
}
- (void)viewDidUnload {
    [self setFriendsListView:nil];
    [super viewDidUnload];
}
@end
