//
//  Annotation.h
//  Roads
//
//  Created by if26 on 19/12/12.
//  Copyright (c) 2012 com.utt.if26. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>
#import <MapKit/MKAnnotation.h>

@interface MyAnnotation : NSObject <MKAnnotation>{
    CLLocationCoordinate2D coordinate;
    NSString* title;
}

@property (nonatomic, assign) CLLocationCoordinate2D coordinate;
@property (nonatomic, copy) NSString* title;
//@property (nonatomic, copy) NSString* subtitle;

-(id)initWithCoordinate:(CLLocationCoordinate2D) c;
-(CLLocationCoordinate2D)getCoordinate;

@end
