//
//  OptionsViewController.h
//  Roads
//
//  Created by if26 on 19/12/12.
//  Copyright (c) 2012 com.utt.if26. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OptionsViewController : UIViewController

@property (retain, nonatomic) IBOutlet UISwitch *switchView;
- (IBAction)changeParamPosition:(id)sender;

@end
