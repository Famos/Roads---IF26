//
//  ErrorNetworkViewController.m
//  Roads
//
//  Created by if26 on 19/12/12.
//  Copyright (c) 2012 com.utt.if26. All rights reserved.
//

#import "ErrorNetworkViewController.h"
#import "ViewController.h"

@interface ErrorNetworkViewController ()

@end

@implementation ErrorNetworkViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)backAuth:(id)sender {
    UIStoryboard* mainStoryBoard = self.storyboard;
    ViewController* viewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"viewController"];
    [self presentViewController:viewController animated:YES completion:nil];
}
@end
