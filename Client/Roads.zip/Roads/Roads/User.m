//
//  User.m
//  Roads
//
//  Created by if26 on 18/12/12.
//  Copyright (c) 2012 com.utt.if26. All rights reserved.
//

#import "User.h"

@implementation User
@synthesize ID, token, expiration, erreur, login, latitude, longitude;

-(User *)initUser{
    if((self = [super init])){
        [self setID:0];
        [self setToken:nil];
        [self setExpiration:nil];
        [self setLogin:nil];
        [self setErreur:0];
        [self setLatitude:0];
        [self setLongitude:0];
    }
    
    return self;
}

//when using the class this will be called: creates one instance
+ (User *) getInstance{
    // Persistent instance.
    static User *_default = nil;
    
    // Small optimization to avoid wasting time after the
    // singleton being initialized.
    if (_default != nil)
    {
        return _default;
    }
    
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= __IPHONE_4_0
    // Allocates once with Grand Central Dispatch (GCD) routine.
    // It's thread safe.
    static dispatch_once_t safer;
    dispatch_once(&safer, ^(void)
                  {
                      _default = [[User alloc] initUser];
                  });
#else
    // Allocates once using the old approach, it's slower.
    // It's thread safe.
    @synchronized([User class])
    {
        // The synchronized instruction will make sure,
        // that only one thread will access this point at a time.
        if (_default == nil)
        {
            _default = [[User alloc] initUser];
        }
    }
#endif
    return _default;
}

@end
