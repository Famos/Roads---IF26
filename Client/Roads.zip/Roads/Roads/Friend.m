//
//  Friend.m
//  Roads
//
//  Created by if26 on 19/12/12.
//  Copyright (c) 2012 com.utt.if26. All rights reserved.
//

#import "Friend.h"

@implementation Friend
@synthesize friendName;
@synthesize friendLatitude;
@synthesize friendLongitude;

-(Friend *)initUser{
    if((self = [super init])){
        [self setFriendName:nil];
        [self setFriendLatitude:0];
        [self setFriendLongitude:0];
        [self setFriendVisibility:0];
    }
    
    return self;
}


//when using the class this will be called: creates one instance
+ (Friend *) getInstance{
    // Persistent instance.
    static Friend *_default = nil;
    
    // Small optimization to avoid wasting time after the
    // singleton being initialized.
    if (_default != nil)
    {
        return _default;
    }
    
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= __IPHONE_4_0
    // Allocates once with Grand Central Dispatch (GCD) routine.
    // It's thread safe.
    static dispatch_once_t safer;
    dispatch_once(&safer, ^(void)
                  {
                      _default = [[Friend alloc] initUser];
                  });
#else
    // Allocates once using the old approach, it's slower.
    // It's thread safe.
    @synchronized([User class])
    {
        // The synchronized instruction will make sure,
        // that only one thread will access this point at a time.
        if (_default == nil)
        {
            _default = [[User alloc] initUser];
        }
    }
#endif
    return _default;
}

@end
