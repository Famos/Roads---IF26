//
//  OptionsViewController.m
//  Roads
//
//  Created by if26 on 19/12/12.
//  Copyright (c) 2012 com.utt.if26. All rights reserved.
//

#import "OptionsViewController.h"
#import "SendPostRequestFunction.h"
#import "User.h"
#import "ViewController.h"
#import "DatabaseController.h"
#import "ErrorNetworkViewController.h"

@implementation OptionsViewController

@synthesize mySwitch;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    [mySwitch addTarget:self action:@selector(switchPosition) forControlEvents:UIControlEventValueChanged];
    
    
    User* user = [User getInstance];
    NSMutableDictionary* dictParams = [[NSMutableDictionary alloc] init];
    [dictParams setObject:[user login] forKey:@"login"];
    [dictParams setObject:[user token] forKey:@"token"];
    NSString* sUserJson = [SendPostRequestFunction postRequest:dictParams withUrl:@"http://localhost:8888/get_localisation.php"];
    
    if(sUserJson == nil) {
        UIStoryboard* mainStoryBoard = self.storyboard;
        ErrorNetworkViewController* errorNetworkViewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"networkError"];
        [self presentViewController:errorNetworkViewController animated:YES completion:nil];
        return;
    }
    
    //Analyser le contenu du JSON reçu
    NSError* error = nil;
    NSData* jsonData = [sUserJson dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary* oUser = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];

    
    //Vérifier au niveau du token
    int erreur = [[oUser valueForKey:@"ERREUR"] intValue];
    if(erreur == -1) {
        DatabaseController* databaseController = [[DatabaseController alloc]init];
        [databaseController createOrOpenDB];
        [databaseController deleteUser];
        
        //Retourner ver l'interface d'authentification
        UIStoryboard* mainStoryBoard = self.storyboard;
        ViewController* viewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"viewController"];
        [self presentViewController:viewController animated:YES completion:nil];
        return;
    }
    
    //Affecter les valeurs
    int loc = [[oUser valueForKey:@"LOC"] intValue];
    if(loc == 1){
        [mySwitch setOn:YES];
    } else {
        [mySwitch setOn:NO];
    }
}

//Changer la visibilité de la position envers tous les amis
- (void)switchPosition {
    User* user = [User getInstance];
    NSMutableDictionary* dictParams = [[NSMutableDictionary alloc] init];
    [dictParams setObject:[user login] forKey:@"login"];
    [dictParams setObject:[user token] forKey:@"token"];


    NSString* sUserJson;
    
    if(mySwitch.on) {
        sUserJson = [SendPostRequestFunction postRequest:dictParams withUrl:@"http://localhost:8888/afficher_position.php"];
        if(sUserJson == nil) {
            UIStoryboard* mainStoryBoard = self.storyboard;
            ErrorNetworkViewController* errorNetworkViewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"networkError"];
            [self presentViewController:errorNetworkViewController animated:YES completion:nil];
            return;
        }
    } else {
        sUserJson = [SendPostRequestFunction postRequest:dictParams withUrl:@"http://localhost:8888/cacher_position.php"];
        if(sUserJson == nil) {
            UIStoryboard* mainStoryBoard = self.storyboard;
            ErrorNetworkViewController* errorNetworkViewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"networkError"];
            [self presentViewController:errorNetworkViewController animated:YES completion:nil];
            return;
        }
    }
    
    //Vérifier au niveau du token
    NSError* error = nil;
    NSData* jsonData = [sUserJson dataUsingEncoding:NSUTF8StringEncoding];
    id jsonDataObject = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];
    if([jsonDataObject isKindOfClass:[NSDictionary class]]) {
        NSDictionary* data = (NSDictionary*) jsonDataObject;
        int erreur = [[data valueForKey:@"ERREUR"] intValue];
        if(erreur == -1) {
            DatabaseController* databaseController = [[DatabaseController alloc]init];
            [databaseController createOrOpenDB];
            [databaseController deleteUser];
            
            //Retourner ver l'interface d'authentification
            UIStoryboard* mainStoryBoard = self.storyboard;
            ViewController* viewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"viewController"];
            [self presentViewController:viewController animated:YES completion:nil];
            return;
        }
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//Action de déconnexion
- (IBAction)logOutBtnClicked:(id)sender {
    DatabaseController* databaseController = [[DatabaseController alloc]init];
    [databaseController createOrOpenDB];
    [databaseController deleteUser];
    
    //Retourner ver l'interface d'authentification
    UIStoryboard* mainStoryBoard = self.storyboard;
    ViewController* viewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"viewController"];
    [self presentViewController:viewController animated:YES completion:nil];
}

- (void)viewDidUnload {
    //[self setSwitchView:nil];
    [self setMySwitch:nil];
    [super viewDidUnload];
}
@end
