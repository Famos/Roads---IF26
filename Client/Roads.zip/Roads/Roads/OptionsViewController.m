//
//  OptionsViewController.m
//  Roads
//
//  Created by if26 on 19/12/12.
//  Copyright (c) 2012 com.utt.if26. All rights reserved.
//

#import "OptionsViewController.h"
#import "SendPostRequestFunction.h"
#import "User.h"


@implementation OptionsViewController

@synthesize switchView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    User* user = [User getInstance];
    NSMutableDictionary* dictParams = [[NSMutableDictionary alloc] init];
    [dictParams setObject:[user login] forKey:@"login"];
    NSString* sUserJson = [SendPostRequestFunction postRequest:dictParams withUrl:@"http://localhost:8888/get_localisation.php"];
    
    //Analyser le contenu du JSON reçu
    NSError* error = nil;
    NSData* jsonData = [sUserJson dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary* oUser = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];
    
    //Affecter les valeurs
    int loc = [[oUser valueForKey:@"LOC"] intValue];
    if(loc == 0){
        [switchView setOn:NO animated:NO];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)changeParamPosition:(id)sender {
    User* user = [User getInstance];
    NSMutableDictionary* dictParams = [[NSMutableDictionary alloc] init];
    [dictParams setObject:[user login] forKey:@"login"];
    if(((UISwitch*)sender).on == TRUE) {
        NSString* sUserJson = [SendPostRequestFunction postRequest:dictParams withUrl:@"http://localhost:8888/afficher_position.php"];
    }
    else{
        NSString* sUserJson = [SendPostRequestFunction postRequest:dictParams withUrl:@"http://localhost:8888/cacher_position.php"];
    }
}

- (void)viewDidUnload {
    [self setSwitchView:nil];
    [super viewDidUnload];
}
@end
