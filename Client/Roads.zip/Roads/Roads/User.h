//
//  User.h
//  Roads
//
//  Created by if26 on 18/12/12.
//  Copyright (c) 2012 com.utt.if26. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface User : NSObject{
    
}

@property (atomic, assign) int ID;
@property (retain, nonatomic)  NSString* token;
@property (retain, nonatomic) NSString* expiration;
@property (retain, nonatomic) NSString* login;
@property (atomic, assign) double latitude;
@property (atomic, assign) double longitude;
@property (atomic, assign) int erreur;

+ (User *) getInstance;

@end
