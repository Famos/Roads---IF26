//
//  NSData+AES.h
//  Roads
//
//  Created by if26 on 10/01/13.
//  Copyright (c) 2013 com.utt.if26. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSData (AES)

- (NSData*)AES256EncryptWithKey:(NSString*)key;
- (NSData*)AES256DecryptWithKey:(NSString*)key;

@end
