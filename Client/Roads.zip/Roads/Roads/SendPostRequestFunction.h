//
//  SendPostRequestFunction.h
//  Roads
//
//  Created by if26 on 18/12/12.
//  Copyright (c) 2012 com.utt.if26. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface SendPostRequestFunction : NSObject{
    
}

+ (NSString *) postRequest:(NSMutableDictionary *)params withUrl:(NSString *)url;

@end
