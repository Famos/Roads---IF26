//
//  AddNewFriendViewController.m
//  Roads
//
//  Created by if26 on 20/12/12.
//  Copyright (c) 2012 com.utt.if26. All rights reserved.
//

#import "AddNewFriendViewController.h"
#import "User.h"
#import "Friend.h"
#import "SendPostRequestFunction.h"
#import "FriendViewController.h"
#import "ErrorNetworkViewController.h"
#import "DatabaseController.h"
#import "ViewController.h"


@implementation AddNewFriendViewController
@synthesize addFriendAsk;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    [self setAddFriendAsk:nil];
    [super viewDidUnload];
}
- (IBAction)btnAddFriendClicked:(id)sender {
    User* user = [User getInstance];
    NSMutableDictionary* dictParams = [[NSMutableDictionary alloc] init];
    [dictParams setObject:[user login] forKey:@"login"];
    [dictParams setObject:[user token] forKey:@"token"];
    Friend* friend = [Friend getInstance];
    [dictParams setObject:[friend friendName] forKey:@"ami"];
    NSString* addFriend = [SendPostRequestFunction postRequest:dictParams withUrl:@"http://localhost:8888/ajout_ami.php"];
    
    if(addFriend == nil) {
        UIStoryboard* mainStoryBoard = self.storyboard;
        ErrorNetworkViewController* errorNetworkViewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"networkError"];
        [self presentViewController:errorNetworkViewController animated:YES completion:nil];
        return;
    } else {
        NSError* error = nil;
        NSData* jsonData = [addFriend dataUsingEncoding:NSUTF8StringEncoding];
        id returnJSONObject = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];
        if([returnJSONObject isKindOfClass:[NSDictionary class]]) {
            NSDictionary* returnJSON = (NSDictionary*) returnJSONObject;
            int erreur = [[returnJSON valueForKey:@"ERREUR"] intValue];
            NSLog(@"erreur = %d", erreur);
            if(erreur == -1) {
                DatabaseController* databaseController = [[DatabaseController alloc]init];
                [databaseController createOrOpenDB];
                [databaseController deleteUser];
                
                //Retourner ver l'interface d'authentification
                UIStoryboard* mainStoryBoard = self.storyboard;
                ViewController* viewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"viewController"];
                [self presentViewController:viewController animated:YES completion:nil];
                return;
            }
            else if(erreur == 0) {
                UIAlertView *alert = [[UIAlertView alloc]
                                      initWithTitle:@""
                                      message:[NSString stringWithFormat:@"%@ a été bien ajouté !",[friend friendName]]
                                      delegate:nil
                                      cancelButtonTitle:@"OK"
                                      otherButtonTitles:nil];
                [alert show];
                
                UIStoryboard* mainStoryBoard = self.storyboard;
                FriendViewController* friendViewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"friendViewController"];
                [friendViewController setReturnButton:1];
                [self presentViewController:friendViewController animated:YES completion:nil];
            }
        }
    }
}
@end
